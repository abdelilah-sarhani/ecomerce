package com.example.ecomerce.data;

import java.io.Serializable;
import java.util.List;

public class Product implements Serializable {
    public int id;
    public String title;
    public String description;
    public String brand;
    public double price;
    public double rating;
    public String thumbnail;
    public List<String> images;
}
