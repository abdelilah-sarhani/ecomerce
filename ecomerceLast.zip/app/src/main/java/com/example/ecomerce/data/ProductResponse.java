package com.example.ecomerce.data;

import java.util.List;

public class ProductResponse {
    public List<Product> products;
    public int total;
    public int skip;
    public int limit;
}
