package com.example.ecomerce.ui;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.ecomerce.R;
import com.example.ecomerce.data.Product;

public class ProductDetailActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        Product p = (Product) getIntent().getSerializableExtra("product");

        ImageView banner = findViewById(R.id.banner);
        TextView title = findViewById(R.id.title);
        TextView price = findViewById(R.id.price);
        TextView desc = findViewById(R.id.desc);

        if (p != null) {
            title.setText(p.title);
            price.setText(String.format("$ %.2f • ⭐ %.1f", p.price, p.rating));
            desc.setText(p.description);
            Glide.with(this).load(p.thumbnail).into(banner);
        }
    }
}
