package com.example.ecomerce.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ecomerce.R;
import com.example.ecomerce.data.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.VH> {
    private final Context ctx;
    private final List<Product> items = new ArrayList<>();

    public ProductAdapter(Context ctx) { this.ctx = ctx; }

    public void setItems(List<Product> data, boolean clear) {
        if (clear) items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.item_product, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Product p = items.get(pos);
        h.title.setText(p.title);
        h.brand.setText(p.brand);
        h.price.setText(String.format("$ %.2f", p.price));
        Glide.with(ctx).load(p.thumbnail).into(h.thumbnail);

        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(ctx, ProductDetailActivity.class);
            i.putExtra("product", p);
            ctx.startActivity(i);
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView thumbnail; TextView title; TextView brand; TextView price;
        VH(@NonNull View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.thumbnail);
            title = itemView.findViewById(R.id.title);
            brand = itemView.findViewById(R.id.brand);
            price = itemView.findViewById(R.id.price);
        }
    }
}
