package com.example.ecomerce.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecomerce.R;
import com.example.ecomerce.data.ProductResponse;
import com.example.ecomerce.net.ApiClient;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.progressindicator.CircularProgressIndicator;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ProductAdapter adapter;
    private int skip = 0;
    private final int limit = 20;
    private boolean loading = false, endReached = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar bar = findViewById(R.id.topAppBar);

        RecyclerView rv = findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductAdapter(this);
        rv.setAdapter(adapter);

        CircularProgressIndicator progress = findViewById(R.id.progress);
        SwipeRefreshLayout swipe = findViewById(R.id.swipe);
        swipe.setOnRefreshListener(() -> {
            skip = 0; endReached = false;
            loadProducts(true, progress, swipe);
        });

        rv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (dy <= 0 || loading || endReached) return;
                LinearLayoutManager lm = (LinearLayoutManager) recyclerView.getLayoutManager();
                int total = lm.getItemCount();
                int last = lm.findLastVisibleItemPosition();
                if (last >= total - 4) loadProducts(false, progress, swipe);
            }
        });

        loadProducts(true, progress, swipe);
    }

    private void loadProducts(boolean clear, CircularProgressIndicator progress, SwipeRefreshLayout swipe) {
        loading = true;
        progress.setVisibility(View.VISIBLE);

        ApiClient.service().getProducts(limit, skip).enqueue(new Callback<ProductResponse>() {
            @Override public void onResponse(Call<ProductResponse> call, Response<ProductResponse> resp) {
                loading = false;
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);

                if (resp.isSuccessful() && resp.body() != null) {
                    if (resp.body().products == null || resp.body().products.isEmpty()) {
                        endReached = true; return;
                    }
                    adapter.setItems(resp.body().products, clear);
                    skip += resp.body().products.size();
                    if (skip >= resp.body().total) endReached = true;
                } else {
                    Toast.makeText(MainActivity.this, "Error: " + resp.code(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onFailure(Call<ProductResponse> call, Throwable t) {
                loading = false;
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                Toast.makeText(MainActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

